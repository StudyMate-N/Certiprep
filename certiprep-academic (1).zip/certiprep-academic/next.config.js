/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['certiprep.academy'],
  },
};

module.exports = nextConfig;
