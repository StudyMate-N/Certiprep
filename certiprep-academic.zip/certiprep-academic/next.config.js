/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: true,
  },
  images: {
    domains: ['certiprep.academy'],
  },
};

module.exports = nextConfig;
