# CertiPrep Academic — Deployment Guide
## From Zero to Live in Under 2 Hours

---

## ARCHITECTURE OVERVIEW

```
Student visits certiprep.academy
         ↓
   [Landing Page] → [Intake Form] → order saved to database
         ↓
   Admin gets notified → [Admin Panel] → sets price + Payoneer link
         ↓
   Quote email sent to student → student clicks Payoneer link → pays
         ↓
   Admin marks as paid → [Admin Panel] → uploads content → activates
         ↓
   Student gets activation email → [Prep Dashboard] → studies 8 days
         ↓
   Day 8 → [Mock Exam] → score + review → Exam day encouragement email
```

**Payment Flow (Payoneer):**
1. Student submits order via intake form
2. Admin reviews in Admin Panel, sets price
3. Admin creates Payoneer invoice, pastes the invoice URL into the "Payment Link" field
4. Quote email sent to student includes "Accept & Pay" button → links to Payoneer invoice
5. Student pays on Payoneer
6. You see payment in Payoneer dashboard
7. You click "Mark as Paid" in Admin Panel
8. System sends payment confirmation email + you build their content

---

## STEP 1: ACCOUNTS (15 minutes)

### 1a. Vercel (Hosting) — FREE
1. Go to [vercel.com](https://vercel.com)
2. Sign up with GitHub
3. That's it for now — we'll connect the project later

### 1b. Supabase (Database) — FREE
1. Go to [supabase.com](https://supabase.com)
2. Create account → New Project
3. **Project name:** certiprep-academic
4. **Database password:** Generate a strong one — SAVE IT
5. **Region:** Pick closest to your students (US East for most)
6. Wait for project to spin up (~2 min)
7. Go to **Settings → Database → Connection String**
8. Copy the URI — replace `[YOUR-PASSWORD]` with your DB password
9. This is your `DATABASE_URL`

### 1c. Resend (Emails) — FREE up to 3,000/month
1. Go to [resend.com](https://resend.com)
2. Sign up → **API Keys** → Create key
3. Save this as your `RESEND_API_KEY`
4. Later: Add your domain for custom "from" address

### 1d. Domain — ~$12/year
1. Go to [namecheap.com](https://namecheap.com) or any registrar
2. Buy your domain (e.g., certiprep.academy)
3. We'll connect it to Vercel in Step 4

### 1e. Payoneer (Payments) — You likely already have this
1. If not, go to [payoneer.com](https://payoneer.com)
2. Set up your account to receive payments
3. The "Request Payment" feature creates invoice links

---

## STEP 2: PROJECT SETUP (20 minutes)

### 2a. Get the code on GitHub
```bash
# On your computer (or use GitHub web upload)
mkdir certiprep-academic
cd certiprep-academic

# Initialize git
git init

# Copy all project files from the download into this folder
# The structure should look like:
#   /app
#   /components  
#   /lib
#   /prisma
#   /public
#   package.json
#   next.config.js
#   .env.example

# Create .env.local from the example
cp .env.example .env.local
# Edit .env.local with your actual values (see Step 1)

# Push to GitHub
git add .
git commit -m "CertiPrep Academic - initial deploy"
git remote add origin https://github.com/YOUR-USERNAME/certiprep-academic.git
git push -u origin main
```

### 2b. Install dependencies locally (optional, for testing)
```bash
npm install
npx prisma db push    # Creates database tables
npm run dev            # Starts at localhost:3000
```

---

## STEP 3: DEPLOY TO VERCEL (10 minutes)

1. Go to [vercel.com/new](https://vercel.com/new)
2. **Import** your GitHub repo: `certiprep-academic`
3. **Framework Preset:** Next.js (auto-detected)
4. **Environment Variables** — Add these:
   ```
   DATABASE_URL          = postgresql://postgres:...@db.xxx.supabase.co:5432/postgres
   ADMIN_PASSWORD        = your-strong-admin-password
   JWT_SECRET            = (generate: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
   RESEND_API_KEY        = re_xxxxxxxxxxxx
   EMAIL_FROM            = CertiPrep Academic <prep@certiprep.academy>
   NEXT_PUBLIC_SUPABASE_URL = https://xxx.supabase.co
   SUPABASE_SERVICE_KEY  = eyJ...
   NEXT_PUBLIC_SITE_URL  = https://certiprep.academy
   ```
5. Click **Deploy**
6. Wait ~2 minutes → Your site is live at `certiprep-academic.vercel.app`

### Push database schema
After first deploy, run locally:
```bash
npx prisma db push
```
This creates all tables in your Supabase database.

---

## STEP 4: CONNECT DOMAIN (10 minutes)

1. In Vercel → Project → **Settings → Domains**
2. Add `certiprep.academy`
3. Vercel gives you DNS records (A record + CNAME)
4. In Namecheap → **DNS → Advanced DNS**:
   - A Record: `@` → `76.76.21.21`
   - CNAME: `www` → `cname.vercel-dns.com`
5. Wait 5-30 minutes for DNS propagation
6. Vercel auto-provisions SSL (HTTPS)

---

## STEP 5: VERIFY EMAIL DOMAIN (10 minutes)

1. In Resend → **Domains** → Add `certiprep.academy`
2. Resend gives you DNS records (SPF, DKIM, DMARC)
3. Add them in Namecheap DNS settings
4. Wait for verification → emails now come from `prep@certiprep.academy`

---

## HOW TO PROCESS AN ORDER (Daily Workflow)

### When a student submits an order:
1. You'll see it in **Admin Panel** (`certiprep.academy/admin`)
2. Review their materials, course, exam date
3. Set the price and select modules

### Setting up payment:
4. Go to **Payoneer** → Request Payment → create invoice for the quoted amount
5. Copy the Payoneer invoice URL
6. In Admin Panel → paste the URL in the **Payment Link** field
7. Click **Send Quote** → student gets email with "Accept & Pay" button

### After student pays:
8. You see payment arrive in Payoneer
9. In Admin Panel → click **Mark as Paid**
10. Student gets payment confirmation email
11. You build their study content (upload to PrepDay records)
12. Click **Activate** → student gets "Your Plan is Live!" email

### While student studies:
13. Daily reminder emails go out automatically (if you set up a cron)
14. Or send manually from Admin Panel

### Exam day:
15. Encouragement email fires on exam date

---

## COST BREAKDOWN

| Service     | Free Tier                  | When to Upgrade            |
|-------------|----------------------------|----------------------------|
| Vercel      | 100GB bandwidth/mo         | $20/mo after ~500 students |
| Supabase    | 500MB DB, 1GB storage      | $25/mo after ~200 orders   |
| Resend      | 3,000 emails/mo            | $20/mo after ~100 students |
| Domain      | $12/year                   | One-time                   |
| **Total**   | **~$12/year to start**     | ~$65/mo at scale           |

---

## FILE STRUCTURE
```
certiprep-academic/
├── app/
│   ├── layout.js              # Root layout (fonts, meta)
│   ├── page.js                # Landing page (/)
│   ├── order/page.js          # Intake form (/order)
│   ├── admin/page.js          # Admin panel (/admin)
│   ├── admin/emails/page.js   # Email templates preview
│   ├── dashboard/
│   │   └── [orderId]/
│   │       ├── page.js        # Prep dashboard
│   │       └── exam/page.js   # Mock exam
│   ├── pay/
│   │   └── [orderId]/page.js  # Payment page (redirects to Payoneer)
│   └── api/
│       ├── auth/route.js      # Admin login
│       └── orders/route.js    # Order CRUD + actions
├── components/                 # Your React components
│   ├── LandingPage.jsx
│   ├── IntakeForm.jsx
│   ├── AdminPanel.jsx
│   ├── EmailTemplates.jsx
│   ├── PrepDashboard.jsx
│   └── ExamSimulation.jsx
├── lib/
│   ├── db.js                  # Prisma client
│   ├── auth.js                # Admin JWT auth
│   └── emails.js              # 5 email templates
├── prisma/
│   └── schema.prisma          # Database models
├── .env.example               # Environment template
├── package.json
└── next.config.js
```

---

## QUICK COMMANDS

```bash
# Development
npm run dev                     # Start local server
npx prisma studio              # Visual database browser

# Database
npx prisma db push             # Push schema changes
npx prisma generate            # Regenerate client

# Deploy
git add . && git commit -m "update" && git push
# Vercel auto-deploys on push to main
```

---

## TROUBLESHOOTING

**"Cannot connect to database"**
→ Check DATABASE_URL in Vercel env vars. Make sure password has no special chars that need URL encoding.

**"Emails not sending"**
→ Check RESEND_API_KEY. Until domain is verified, emails come from onboarding@resend.dev.

**"Admin login not working"**
→ Check ADMIN_PASSWORD env var matches what you're typing. Clear cookies and retry.

**"Payoneer link not working"**
→ Make sure you copy the FULL invoice URL from Payoneer. Test it in incognito first.
