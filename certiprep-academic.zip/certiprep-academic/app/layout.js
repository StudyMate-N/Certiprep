export const metadata = {
  title: 'CertiPrep Academic — Personalized Exam Preparation',
  description: 'Custom study plans, flashcards, video lessons, and mock exams tailored to your exact syllabus.',
  openGraph: {
    title: 'CertiPrep Academic',
    description: 'Custom study plans built from your actual course materials. Study guides, flashcards, videos, quizzes, and mock exams.',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&family=Libre+Baskerville:wght@400;700&display=swap" rel="stylesheet" />
      </head>
      <body style={{ margin: 0, padding: 0 }}>
        {children}
      </body>
    </html>
  );
}
