import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdmin } from '@/lib/auth';
import { sendQuoteEmail, sendPaymentEmail, sendActivationEmail } from '@/lib/emails';

// Generate readable order number
function genOrderNumber() {
  const num = Math.floor(1000 + Math.random() * 9000);
  return `ORD-${num}`;
}

// ──── GET /api/orders ────
// Admin: fetch all orders
// Student: fetch by email (query param)
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const email = searchParams.get('email');
  const id = searchParams.get('id');

  // Single order by ID (for student dashboard)
  if (id) {
    const order = await db.order.findUnique({
      where: { id },
      include: { prepDays: { orderBy: { dayNumber: 'asc' } }, examAttempts: true },
    });
    if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json(order);
  }

  // Admin: all orders
  const isAdmin = await verifyAdmin();
  if (isAdmin) {
    const orders = await db.order.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json(orders);
  }

  // Student: orders by email
  if (email) {
    const orders = await db.order.findMany({
      where: { studentEmail: email },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(orders);
  }

  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
}

// ──── POST /api/orders ────
// Create new order from intake form
export async function POST(req) {
  try {
    const body = await req.json();
    const {
      studentName, studentEmail, school, courseCode, courseName,
      examType, examDate, commitment, topics, notes, files
    } = body;

    // Calculate duration (days until exam)
    const duration = Math.max(1, Math.ceil((new Date(examDate) - new Date()) / 86400000));

    const order = await db.order.create({
      data: {
        orderNumber: genOrderNumber(),
        studentName,
        studentEmail,
        school: school || '',
        courseCode: courseCode || '',
        courseName: courseName || courseCode || '',
        examType,
        examDate: new Date(examDate),
        duration,
        commitment: commitment || '2-3hr',
        topics: topics || '',
        notes: notes || '',
        files: JSON.stringify(files || []),
        status: 'pending',
      },
    });

    return NextResponse.json(order, { status: 201 });
  } catch (err) {
    console.error('Order creation error:', err);
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 });
  }
}

// ──── PATCH /api/orders ────
// Admin actions: send quote, set payment link, mark paid, activate, reject
export async function PATCH(req) {
  const isAdmin = await verifyAdmin();
  if (!isAdmin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const { id, action, ...data } = body;

    if (!id || !action) {
      return NextResponse.json({ error: 'Missing id or action' }, { status: 400 });
    }

    const order = await db.order.findUnique({ where: { id } });
    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });

    switch (action) {
      // ── SEND QUOTE ──
      case 'quote': {
        const { amount, modules, note, paymentLink } = data;
        const updated = await db.order.update({
          where: { id },
          data: {
            status: 'quoted',
            quoteAmount: parseFloat(amount),
            quoteModules: JSON.stringify(modules || []),
            quoteNote: note || null,
            paymentLink: paymentLink || null, // Payoneer invoice URL
            quoteSentAt: new Date(),
          },
        });
        // Send quote email with Payoneer payment link
        await sendQuoteEmail(updated).catch(err => console.error('Email error:', err));
        return NextResponse.json(updated);
      }

      // ── SET PAYMENT LINK (Payoneer) ──
      case 'setPaymentLink': {
        const { paymentLink } = data;
        const updated = await db.order.update({
          where: { id },
          data: { paymentLink },
        });
        return NextResponse.json(updated);
      }

      // ── MARK AS PAID ──
      case 'markPaid': {
        const updated = await db.order.update({
          where: { id },
          data: {
            status: 'paid',
            paidAt: new Date(),
          },
        });
        // Send payment confirmation email
        await sendPaymentEmail(updated).catch(err => console.error('Email error:', err));
        return NextResponse.json(updated);
      }

      // ── ACTIVATE (content ready) ──
      case 'activate': {
        const updated = await db.order.update({
          where: { id },
          data: {
            status: 'active',
            activatedAt: new Date(),
          },
        });
        // Send activation email
        await sendActivationEmail(updated).catch(err => console.error('Email error:', err));
        return NextResponse.json(updated);
      }

      // ── REJECT ──
      case 'reject': {
        const updated = await db.order.update({
          where: { id },
          data: { status: 'rejected' },
        });
        return NextResponse.json(updated);
      }

      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }
  } catch (err) {
    console.error('Order update error:', err);
    return NextResponse.json({ error: 'Failed to update order' }, { status: 500 });
  }
}
